# CamViewerRtsp
<h1>Description</h1>
<p>This small application let you stream video with a webcam or the raspberry pi cam. </p>
<h2>Installation</h2>
